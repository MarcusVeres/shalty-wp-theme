<?php
/**
 * Shaltazar Post Module Loader
 * Add this to your inc/core/loader.php file or create this as inc/modules/shaltazar-post/index.php
 * 
 * @package ChildTheme
 * @subpackage Modules/ShaltazarPost
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Load Shaltazar Post Module Files
 */
function load_shaltazar_post_module() {
    $module_path = get_stylesheet_directory() . '/inc/modules/shaltazar-post/';
    
    // Check if module directory exists
    if (!is_dir($module_path)) {
        return;
    }
    
    // Load module files in order
    $files = array(
        'utilities.php',    // Load utilities first
        'post-type.php',    // Then post type registration
        'admin.php',        // Admin functionality
        'frontend.php'      // Frontend functionality
    );
    
    foreach ($files as $file) {
        $file_path = $module_path . $file;
        if (file_exists($file_path)) {
            require_once $file_path;
        }
    }
}

// Hook into init with high priority to ensure post type is registered early
add_action('init', 'load_shaltazar_post_module', 5);

/**
 * Activation hook to flush rewrite rules
 * Call this function manually after adding the module
 */
function activate_shaltazar_post_module() {
    load_shaltazar_post_module();
    flush_rewrite_rules();
}

/**
 * Module information (optional - for documentation)
 */
function get_shaltazar_post_module_info() {
    return array(
        'name' => 'Shaltazar Post Module',
        'version' => '1.0.0',
        'description' => 'Custom post type for channeled content with ACF integration',
        'requires' => array(
            'Advanced Custom Fields' => 'get_field function for custom fields'
        ),
        'features' => array(
            'Custom post type registration',
            'Admin column customization',
            'Frontend display functions',
            'Schema.org structured data',
            'YouTube and media link utilities',
            'Theme and content type filtering'
        )
    );
}
